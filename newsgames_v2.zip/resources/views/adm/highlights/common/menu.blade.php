<ul>
    <li @if($menu == 'highlight') ?? class="active" @endif>
       <a href="{{ route('destaques.index') }}"><i class="fa-solid fa-list-ul"></i> Lista</a>
    </li>
</ul>