<div class="ajax_load"  style="z-index: 998">
    <div class="lds-ripple"><div></div><div></div></div>
</div>