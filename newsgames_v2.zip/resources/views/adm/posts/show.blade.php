<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Visualizar</title>

    <!-- App Style -->
    <link rel="stylesheet" href="{{ url(mix('assets/css/adm/app.css')) }}">

    <style>
        body {
            max-width: 800px;
            margin-top: 20px;
        }

        .htmlchars {
            padding: 5px;
            border: 2px solid black;
        }
    </style>
</head>
<body>
    <div class="htmlchars">
        {!! $article->content !!}
    </div>
</body>
</html>