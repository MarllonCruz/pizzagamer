

<?php $__env->startSection('content'); ?>
   <section>
      <h2>Slides</h2>

      <div class="content">
         <div class="left">
            <?php echo $__env->make('adm.slides.common.menu', ['menu', $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
         <div class="right">
            <header>
               <h2><i class="fa-solid fa-pen-to-square"></i> Listas de Slides</h2>
            </header>

            <div class="list-slides">
               <ul class="positions">
                  <li>1</li>
                  <li>2</li>
                  <li>3</li>
                  <li>4</li>
                  <li>5</li>
                  <li>6</li>
                  <li>7</li>
                  <li>8</li>
                  <li>9</li>
                  <li>10</li>
               </ul>

               <ul class="slide" id="sortable" data-route="<?php echo e(route('slides.sortable')); ?>">
                  <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                     <?php if(!$slide->article): ?>
                        <li class="item empty" data-id="<?php echo e($slide->id); ?>">
                           <p><i class="fa-solid fa-face-frown-open"></i> Vazio</p>
                        </li>
                     <?php else: ?>
                        <li class="item" data-id="<?php echo e($slide->id); ?>">
                           <p><?php echo e($slide->article->title); ?> (<?php echo e($slide->article->category->title); ?>)</p>
                           <a class="remove" href="<?php echo e(route('slides.destroy', ['slide' => $slide->id])); ?>" onclick="return confirm('Tem certeza que remover <?php echo e($slide->article->title); ?> ?')">
                              <i class="fa-solid fa-trash-can"></i> Remover
                           </a>
                        </li>
                     <?php endif; ?>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               </ul>
            </div>
         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
   <script src="<?php echo e(url('assets/js/jquery-sortable.js')); ?>"></script>
   <script>
      //Ajax Sortable by [JQuery]
      async function requestAjaxByJQuery(route) {
         list = [];
         $(".item").each((index, obj)=> {
            list.push($(obj).attr("data-id")); 
         });

         $.ajax({
            url: route,
            data: {
               "_token": $('meta[name="csrf-token"]').attr('content'),
               "list": list
            },
            type: "POST",
            dataType: "json",
            success: function (su) {
               console.log(su);
            }
         });
      }

      // SortableJS
      var route = $('#sortable').data('route');

      var el = document.getElementById('sortable');
      Sortable.create(el, {
         group: 'shared',
         swapThreshold: 0.90,
         animation: 300,
         onUpdate: async function() {
            requestAjaxByJQuery(route);
         }
      });
   </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.common.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/slides/home.blade.php ENDPATH**/ ?>