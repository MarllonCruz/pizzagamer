<div class="list-post">
    <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <div class="post">
          <img src="<?php echo e(url('storage/' . $article->cover)); ?>" alt="">  

          <a target="_blank" href="<?php echo e(route("{$route}.show", ["{$param}" => $article->id])); ?>"><?php echo e($article->title); ?></a>

          <div class="status-post">
             <span><i class="fa-solid fa-clock"></i> <?php echo e(date_fmt($article->updated_at, 'd/m/Y H:i')); ?></span>
             <?php if(isset($article->category->title)): ?>
               <span><i class="fa-solid fa-bookmark"></i> <?php echo e($article->category->title); ?></span>
             <?php endif; ?>
             <span><i class="fa-solid fa-user"></i> <?php echo e($article->user->fullName()); ?></span>
             <span><i class="fa-solid fa-pen-to-square"></i> <?php echo e($article->statusPtBr()); ?></span>
          </div>

          <div class="btns">
             <a href="<?php echo e(route("{$route}.edit", ["{$param}" => $article->id])); ?>"><i class="fa-solid fa-pen"></i> Editar</a>
             <a href="<?php echo e(route("{$route}.destroy", ["{$param}" => $article->id])); ?>" onclick="return confirm('Tem certeza que deseja excluir categoria <?php echo e($article->title); ?> ?')"><i class="fa-solid fa-trash-can"></i> Deletar</a>
          </div>
       </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 </div>

 <?php echo e($articles->links('adm.common.pagination-custom')); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/common/list-post-or-video.blade.php ENDPATH**/ ?>