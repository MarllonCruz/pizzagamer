<section class="width-full mt-20 feed-slideshow-responsive">
    <div class="feed-slideshow container center">
        <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div <?php if($key==0): ?> class="slide active" <?php else: ?> class="slide" <?php endif; ?>>
                <img src="<?php echo e(url('storage/' . $slide->cover)); ?>" alt="" />
                <div class="slide-info">
                    <h2><?php echo e($slide->title); ?></h2>
                    <p><?php echo e($slide->description); ?></p>
                    <a href="<?php echo e(route('noticia', ['uri' => $slide->uri])); ?>">Mais Detalhes</a> 
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <div class="navigation">
            <?php $__currentLoopData = $slides; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $slide): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div <?php if($key==0): ?> class="btn active" <?php else: ?> class="btn" <?php endif; ?>></div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><?php /**PATH C:\projetos\newsgames_v2\resources\views/web/common/slide.blade.php ENDPATH**/ ?>