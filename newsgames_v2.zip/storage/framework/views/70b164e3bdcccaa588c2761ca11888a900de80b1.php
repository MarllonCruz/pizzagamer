

<?php $__env->startSection('content'); ?>
   <section>
      <h2>Videos</h2>

      <div class="content">
         <div class="left">
            <?php echo $__env->make('adm.videos.common.menu', ['menu', $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
         <div class="right post">
            <header>
               <h2><i class="fa-solid fa-square-plus"></i>Editar Video</h2>
               <area />
            </header>

            <form action="<?php echo e(route('videos.update', ['video' => $article->id])); ?>" method="post" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
               <input type="hidden" name="id" value="<?php echo e($article->id); ?>">

               <label for="title">*Titulo</label>
               <input type="text" name="title" placeholder=" Titulo" id="title"
                  value="<?php if(old('title')): ?> <?php echo e(old('title')); ?> <?php else: ?> <?php echo e($article->title); ?> <?php endif; ?>" 
                  <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> class="is-invalid" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
               <?php $__errorArgs = ['title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="alert alert-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               
               <label for="description">*Descrição</label>
               <input type="text" name="description" placeholder=" Descrição" id="description"
                  value="<?php if(old('description')): ?> <?php echo e(old('description')); ?> <?php else: ?> <?php echo e($article->description); ?> <?php endif; ?>"  
                  <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> class="is-invalid" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
               <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="alert alert-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

               <label for="video">*Link do video youtube</label>
               <input type="text" name="video" id="video" placeholder=" Exp: https://www.youtube.com/watch?v=JORwlHKBvbI" 
               value="<?php if(old('video')): ?> <?php echo e(old('video')); ?> <?php else: ?> <?php echo e($article->video); ?> <?php endif; ?>" <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> class="is-invalid" <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>>
               <?php $__errorArgs = ['video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="alert alert-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

               <div class="form-group">
                    <div class="form">
                        <label for="description">Data de estreia</label>
                        <input type="datetime-local"  name="opening_at" id="opeming_at"
                            value="<?php echo e(date_fmt($article->opening_at, 'Y-m-d\TH:i')); ?>">
                    </div>

                    <div class="form">
                        <label for="status">Status</label>
                        <select name="status" id="status">
                            <option value="active" <?php if($article->status == 'active'): ?> selected <?php endif; ?>>Ativo</option>
                            <option value="draft" <?php if($article->status == 'draft'): ?> selected <?php endif; ?>>Rascunho</option>
                            <option value="trash" <?php if($article->status == 'trash'): ?> selected <?php endif; ?>>Lixo</option>
                        </select>
                    </div>
               </div>

               <label for="cover">*Capa</label>
               <div class="cover-box">
                    <?php if(!empty($article->cover)): ?>
                        <img src="<?php echo e(url('storage/' . $article->cover)); ?>" alt="">      
                    <?php endif; ?>
                </div>
               <input type="file" name="cover" id="cover">
               <?php $__errorArgs = ['cover'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="alert alert-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

               <div class="al-right">
                  <button type="submit"><i class="fa-solid fa-square-check"></i> Salvar Artigo</button>
               </div>
            </form>
         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.common.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/videos/edit.blade.php ENDPATH**/ ?>