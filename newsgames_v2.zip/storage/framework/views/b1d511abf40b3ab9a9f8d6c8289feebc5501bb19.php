<header>
    <span><?php echo e(auth()->user()->fullName()); ?></span>
    <div class="profile">
        <img src="<?php echo e(url('storage/' . auth()->user()->photo)); ?>" alt="">
    </div>
</header><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/common/main-header.blade.php ENDPATH**/ ?>