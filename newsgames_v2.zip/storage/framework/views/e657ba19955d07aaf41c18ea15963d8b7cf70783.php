

<?php $__env->startSection('content'); ?>
   <section>
      <h2>Slides</h2>

      <div class="content">
         <div class="left">
            <?php echo $__env->make('adm.slides.common.menu', ['menu', $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
         <div class="right">
            <header>
               <h2><i class="fa-solid fa-pen-to-square"></i> Adicionar</h2>
            </header>

            <div class="add">
                <form action="<?php echo e(route('slides.store')); ?>" method="post">
                    <?php echo csrf_field(); ?>
                    <label>Seleciona um artigo</label>
                
                    <select name="article_id">
                        <?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($article->id); ?>">
                                    Titulo: <?php echo e($article->title); ?> (<?php echo e($article->category->title); ?>)
                                </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <div class="al-right">
                        <button type="submit"><i class="fa-solid fa-square-check"></i> Adicionar</button>
                    </div>
                </form>
            </div>
         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.common.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/slides/add.blade.php ENDPATH**/ ?>