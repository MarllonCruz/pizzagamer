<ul>
    <li <?php if($menu == 'slide'): ?> ?? class="active" <?php endif; ?>>
       <a href="<?php echo e(route('slides.index')); ?>"><i class="fa-solid fa-list-ul"></i> Lista</a>
    </li>
    <li <?php if($menu == 'add'): ?> ?? class="active" <?php endif; ?>>
        <a href="<?php echo e(route('slides.create')); ?>"><i class="fa-solid fa-pen-to-square"></i> Adicionar</a>
     </li>
</ul><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/slides/common/menu.blade.php ENDPATH**/ ?>