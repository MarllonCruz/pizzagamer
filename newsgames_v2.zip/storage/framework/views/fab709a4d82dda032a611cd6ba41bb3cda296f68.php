

<?php $__env->startSection('content'); ?>
   <section>
      <h2>Destaques</h2>

      <div class="content">
         <div class="left">
            <?php echo $__env->make('adm.highlights.common.menu', ['menu', $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
         <div class="right">
            <header>
               <h2><i class="fa-solid fa-pen-to-square"></i> Listas de Destaque</h2>
            </header>

            <div class="highlights">
                <?php $__currentLoopData = $highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="highlight">
                        <h2>Destaque <?php echo e($highlight->title); ?></h2>
                        <?php if(!$highlight->article): ?>
                            <p><i class="fa-solid fa-face-frown-open"></i> Vazio</p>
                            <a class="btn add" href="<?php echo e(route('destaques.create', ['highlight' => $highlight->id])); ?>">
                                <i class="fa-solid fa-square-plus"></i> Adicionar
                            </a>
                        <?php else: ?> 
                            <p><?php echo e($highlight->article->title); ?> (<?php echo e($highlight->article->category->title); ?>)</p>
                            <a class="btn remove" href="<?php echo e(route('destaques.destroy', ['highlight' => $highlight->id])); ?>" onclick="return confirm('Tem certeza que remover artigo: <?php echo e($highlight->article->title); ?> ?')">
                                <i class="fa-solid fa-trash-can"></i> Remover
                            </a> 
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.common.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/highlights/home.blade.php ENDPATH**/ ?>