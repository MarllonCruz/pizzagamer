<ul>
    <li <?php if($menu == 'videos'): ?> ?? class="active" <?php endif; ?>>
       <a href="<?php echo e(route('videos.index')); ?>"><i class="fa-solid fa-pen-to-square"></i> Videos</a>
    </li>
    <li <?php if($menu == 'new-video'): ?> ?? class="active" <?php endif; ?>>
       <a href="<?php echo e(route('videos.create')); ?>"><i class="fa-solid fa-square-plus"></i> Novo Video</a>
    </li>
</ul><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/videos/common/menu.blade.php ENDPATH**/ ?>