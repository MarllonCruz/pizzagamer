<ul>
    <li <?php if($menu == 'posts'): ?> ?? class="active" <?php endif; ?>>
       <a href="<?php echo e(route('artigos.index')); ?>"><i class="fa-solid fa-pen-to-square"></i> Artigos</a>
    </li>
    <li <?php if($menu == 'category'): ?> ?? class="active" <?php endif; ?>>
       <a href="<?php echo e(route('artigos.categorias.index')); ?>"><i class="fa-solid fa-bookmark"></i> Categorias</a>
    </li>
    <li <?php if($menu == 'new-post'): ?> ?? class="active" <?php endif; ?>>
       <a href="<?php echo e(route('artigos.create')); ?>"><i class="fa-solid fa-square-plus"></i> Novo Artigo</a>
    </li>
</ul><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/posts/common/menu.blade.php ENDPATH**/ ?>