<section class="width-full my-20 feed-videos-responsive">
    <div class="feed-videos container center">
        <div class="header">
            <h4>Videos</h4>
            <a href="<?php echo e(route('listagem', ['type' => 'video'])); ?>">Ver todos</a>
        </div>
        <div class="body">
            <?php $__currentLoopData = $videos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $video): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="box">
                    <div class="video" href="#" 
                        data-modal=".home_video_modal" 
                        data-uri="<?php echo e($video->video); ?>">
                            <div class="box-img">
                                <img src="<?php echo e(url('storage/' . $video->cover)); ?>" alt="">
                                <i class="fa-solid fa-play"></i>
                            </div>
                        </div>
                    <a href="<?php echo e(route('video', ['uri' => $video->uri])); ?>"><?php echo e($video->title); ?></a>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <div class="home_video_modal j_modal_close">
        <div class="home_video_modal_box">
            <div class="embed">
                <iframe width="560" class="iframe_1"
                    src=""
                    frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\projetos\newsgames_v2\resources\views/web/common/video.blade.php ENDPATH**/ ?>