

<?php if($type == 'noticia'): ?>
	<?php $__env->startSection('title', ' - Notícias'); ?>
	<?php $routeUri =  'noticia' ?>
<?php else: ?>
	<?php $__env->startSection('title', ' - Videos'); ?>
	<?php $routeUri =  'video' ?>
<?php endif; ?>

<?php $__env->startSection('content'); ?>
	<main class="width-full">
		<section class="news-page container center">
			<div class="news-header">
				<h1><?php echo e($title); ?></h1>
				<p><?php echo e($description); ?></p>
				<form class="search-box" method="post" action="<?php echo e(route("listagem.search", ['type' => $type])); ?>">
					<?php echo csrf_field(); ?>
					<input type="text" name="s" value="<?php echo e($searchInput); ?>" placeholder="<?php echo e($placeholderInput); ?>">
					<button><i class="fa-solid fa-magnifying-glass"></i></button>
				</form>
			</div>
			<div class="news_content mt-20">
				<?php $__currentLoopData = $articles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<article>
						<a class="box-img" href="<?php echo e(route($routeUri, ['uri' => $article->uri])); ?>">
							<img src="<?php echo e(url("storage/{$article->cover}")); ?>" alt="">
						</a>
						<header>
							<p class="meta">
								<?php if(!empty($article->category_id)): ?> 
									<a href="<?php echo e(route('listagem.category', ['category' =>$article->category->uri])); ?>"
										><?php echo e($article->category->title); ?></a> •
								<?php endif; ?> 
								<?php echo e($article->user->fullName()); ?> • <?php echo e(date_fmt_custom($article->created_at)); ?>

							</p>
							<h2>
								<a href="<?php echo e(route($routeUri, ['uri' => $article->uri])); ?>"><?php echo e($article->title); ?></a>
							</h2>
							<p> 
								<a href="<?php echo e(route($routeUri, ['uri' => $article->uri])); ?>"><?php echo e($article->description); ?></a> 
							</p>
						</header>
					</article>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</div>
			<?php echo e($articles->links('web.common.pagination-custom')); ?>

		</section>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/web/pages/list.blade.php ENDPATH**/ ?>