<section class="others-articles container center">
    <div class="others-articles-header">
        <h1>Veja também:</h1>
        <p>Confira mais notícias e estar por dentro no mundo dos games</p>
    </div>
    <div class="others-articles-body">
        <?php $__currentLoopData = $othersArticles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $article): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article>
                <a class="box-img" href="<?php echo e(route($routeUri, ['uri' => $article->uri])); ?>">
                    <img src="<?php echo e(url("storage/{$article->cover}")); ?>" alt="">
                </a>
                <header>
                    <p class="meta">
                        <?php if(!empty($article->category_id)): ?> 
							<a href="<?php echo e(route('listagem.category', ['category' =>$article->category->uri])); ?>"
								><?php echo e($article->category->title); ?></a> •
						<?php endif; ?> 
                        <?php echo e($article->user->fullName()); ?> • <?php echo e(date_fmt_custom($article->created_at)); ?>

                    </p>
                    <h2>
                        <a href="<?php echo e(route($routeUri, ['uri' => $article->uri])); ?>">
                           <?php echo e($article->title); ?>

                        </a>
                    </h2>
                    <p> 
                        <a href="<?php echo e(route($routeUri, ['uri' => $article->uri])); ?>">
                            <?php echo e($article->description); ?>

                        </a> 
                    </p>
                </header>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</section><?php /**PATH C:\projetos\newsgames_v2\resources\views/web/common/others-articles.blade.php ENDPATH**/ ?>