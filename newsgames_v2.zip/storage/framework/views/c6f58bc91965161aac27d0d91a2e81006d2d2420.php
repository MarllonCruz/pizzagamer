<div class="mce_upload" style="z-index: 997">
    <div class="mce_upload_box">
        <form class="app_form" action="<?php echo e(route('mce_uplaod')); ?>" method="post" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>

            <input type="hidden" name="upload" value="true"/>
            <label>
                <label class="legend">Selecione uma imagem JPG ou PNG:</label>
                <span class="mce_response"></span>
                <input accept="image/*" type="file" name="image" required/>
            </label>
            <button class="btn btn-blue icon-upload">Enviar Imagem</button>
        </form>
    </div>
</div><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/common/mce-upload.blade.php ENDPATH**/ ?>