<aside id="menu-aside">
    <div class="logo">
        Ghost Gamer Adm
    </div>
    <nav class="nav-menu">
        
        <a href="<?php echo e(route('artigos.index')); ?>" 
            <?php if($page == 'post'): ?> ?? class="active" <?php endif; ?>><i class="fa-solid fa-newspaper"></i> Artigos
        </a>
        <a href="<?php echo e(route('slides.index')); ?>" 
            <?php if($page == 'slide'): ?> ?? class="active" <?php endif; ?>><i class="fa-solid fa-sliders"></i> Slides
        </a>
        <a href="<?php echo e(route('destaques.index')); ?>" 
        <?php if($page == 'highlight'): ?> ?? class="active" <?php endif; ?>><i class="fa-solid fa-bookmark"></i> Destaques
        </a>
        <a href="<?php echo e(route('videos.index')); ?>" 
            <?php if($page == 'video'): ?> ?? class="active" <?php endif; ?>><i class="fa-solid fa-clapperboard"></i> Videos
        </a>
        <a href="<?php echo e(route('usuarios.index')); ?>" 
            <?php if($page == 'user'): ?> ?? class="active" <?php endif; ?>><i class="fa-solid fa-user"></i> Usuários
        </a>
        <a href="<?php echo e(route('admin.logout')); ?>">
            <i class="fa-solid fa-door-open"></i> Sair
        </a>
    </nav>
</aside><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/common/sidebar.blade.php ENDPATH**/ ?>