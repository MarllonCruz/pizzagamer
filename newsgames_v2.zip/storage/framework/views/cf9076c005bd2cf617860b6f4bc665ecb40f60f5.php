<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="icon" type="image/gif/png" href="<?php echo e(url('storage/media/pizza/default.png')); ?>">

    <title><?php echo e(config('app.name')); ?> | Admin</title>

    <!-- Fontawesome style -->
    <link rel="stylesheet" href="<?php echo e(url(mix('assets/css/fontawesome.css'))); ?>">
    <!-- App Style -->
    <link rel="stylesheet" href="<?php echo e(url(mix('assets/css/adm/app.css'))); ?>">
</head>
<body id="adm_body">
    <!-- Ajax Loading -->
    <?php echo $__env->make('adm.common.ajax-load', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- MCE Upload -->
    <?php echo $__env->make('adm.common.mce-upload', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Aside -->
    <?php echo $__env->make('adm.common.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Button menu by aside -->
    <button id="btn-menu">
        <i class="fa-solid fa-bars-staggered"></i>
    </button>

    <!-- Main -->
    <main>
        <!-- Main Header -->
        <?php echo $__env->make('adm.common.main-header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- Content -->
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <!-- Flasher PHP -->
    <?php echo app('flasher.response_manager')->render(); ?>

    <!-- Fontawesome script -->
    <script src="<?php echo e(url('assets/js/fontawesome.js')); ?>"></script>
    <!-- JQuery -->
    <script src="<?php echo e(url('assets/js/jquery.min.js')); ?>"></script>
    <!-- JQuery Ui -->
    <script src="<?php echo e(url('assets/js/jquery-ui.js')); ?>"></script>
    <!-- JQuery Form -->
    <script src="<?php echo e(url('assets/js/jquery.form.js')); ?>"></script>
    <!-- Chart -->
    <script src="<?php echo e(url('assets/js/chart.js')); ?>"></script>
    <!-- TinyMCE -->
    <script src="<?php echo e(url("assets/js/tinymce/tinymce.min.js")); ?>"></script> 
    <!-- App Script -->
    <script src="<?php echo e(url(mix('assets/js/adm/app.js'))); ?>"></script>
    <!-- Section script -->
    <?php echo $__env->yieldContent('script'); ?>
</body>
</html><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/common/template.blade.php ENDPATH**/ ?>