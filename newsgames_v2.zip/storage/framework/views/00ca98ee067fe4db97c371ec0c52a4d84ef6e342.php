

<?php $__env->startSection('title', " - {$article->title}"); ?>

<?php $__env->startSection('content'); ?>
	<!-- Article Post -->
    <main class="width-full">
        <article class="article container center">
            <h1><?php echo e($article->title); ?></h1>
            <img src="<?php echo e(url("storage/{$article->cover}")); ?>" alt="" >
            <div class="info">
                <div class="author">
                    <div class="avatar"><img src="<?php echo e(url("storage/{$article->user->photo}")); ?>" alt=""></div>
                    <div class="name">Por: <?php echo e($article->user->fullName()); ?></div>
                </div>
                <div class="date"><?php echo e(date_fmt_custom($article->created_at)); ?></div>
            </div>

            <div class="htmlchars"><?php echo $article->content; ?></div>
        </article>
        <!-- Others Articles -->
        <?php echo $__env->make('web.common.others-articles', ['routeUri' => 'noticia'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/web/pages/post.blade.php ENDPATH**/ ?>