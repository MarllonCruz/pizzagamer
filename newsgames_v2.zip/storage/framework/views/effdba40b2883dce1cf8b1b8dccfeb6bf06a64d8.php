

<?php $__env->startSection('content'); ?>
   <section>
      <h2>Usuários</h2>

      <div class="content">
         <div class="left">
            <?php echo $__env->make('adm.users.common.menu', ['menu', $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
         <div class="right post">
            <header>
               <h2><i class="fa-solid fa-pen-to-square"></i> Lista</h2>

               <form class="form-search" id="form-post-search" action="<?php echo e(route('usuarios.search.ajax')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <button><i class="fa-solid fa-magnifying-glass"></i></button>
                  <input type="text" name="s" value="<?php echo e($search); ?>">
               </form>
            </header>

            <div class="list">
               <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="user">
                     <div class="photo">
                        <img src="<?php echo e(url('storage/' . $user->photo)); ?>" alt="">
                     </div>
                     <span><i class="fa-solid fa-user"></i> <?php echo e($user->level()); ?></span>
                     <h3><?php echo e($user->fullName()); ?> <?php if($user->id == auth()->user()->id): ?> ( Você ) <?php endif; ?></h3>
                     <span><?php echo e($user->email); ?></span>
                     <span>Desde <?php echo e(date_fmt_custom($user->created_at)); ?></span>

                     <div class="btns">
                        <a href="<?php echo e(route("usuarios.edit", ["user" => $user->id])); ?>"><i class="fa-solid fa-pen"></i> Editar</a>
                        <a href="<?php echo e(route("usuarios.destroy", ["user" => $user->id])); ?>" onclick="return confirm('Tem certeza que deseja excluir usuário <?php echo e($user->fullName()); ?> ?')"><i class="fa-solid fa-trash-can"></i> Deletar</a>
                     </div>
                  </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

               <?php echo e($users->links('adm.common.pagination-custom')); ?>

            </div>
         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.common.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/users/home.blade.php ENDPATH**/ ?>