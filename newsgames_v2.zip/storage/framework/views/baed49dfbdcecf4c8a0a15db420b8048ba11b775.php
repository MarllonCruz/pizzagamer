<div class="ajax_load"  style="z-index: 998">
    <div class="lds-ripple"><div></div><div></div></div>
</div><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/common/ajax-load.blade.php ENDPATH**/ ?>