<header class="width-full">
    <nav class="container center">
        <div class="nav-top">
            <p class="nav-top--numb">Cel: +01 123 456 7890</p>
            <ul class="nav-top--social">
                <li><a><i class="fa-brands fa-twitter"></i></a></li>
                <li><a><i class="fa-brands fa-linkedin-in"></i></a></li>
                <li><a><i class="fa-brands fa-github-alt"></i></a></li>
            </ul>
        </div>
        <div class="nav-separate"></div>
        <div class="nav-menu">
            <div class="nav-menu--log">
                <a href="<?php echo e(route('home')); ?>"><i class="fa-solid fa-ghost"></i>Ghost Gamer</a>
            </div>
            <div class="nav-menu--menus">
                <ul>
                    <div class="nav-menu--btn-close">
                        <i class="fa-solid fa-right-long"></i>
                    </div>
                    <li><a <?php if($page == "home"): ?> class="active" <?php endif; ?> href="<?php echo e(route('home')); ?>">HOME</a></li>
                    <li><a <?php if($page == "post"): ?> class="active" <?php endif; ?> href="<?php echo e(route('listagem', ['type' => 'noticia'])); ?>">NOTÍCIAS</a></li>
                    <li><a <?php if($page == "video"): ?> class="active" <?php endif; ?> href="<?php echo e(route('listagem', ['type' => 'video'])); ?>">VIDEOS</a></li>
                </ul>
            </div>
            <div class="nav-menu--btn-open">
                <i class="fa-solid fa-bars"></i>
            </div>
        </div>
    </nav>
</header><?php /**PATH C:\projetos\newsgames_v2\resources\views/web/common/header.blade.php ENDPATH**/ ?>