<section class="width-full mt-20 feed-highlights-responsive">
    <div class="feed-highlights container center">

        <?php $__currentLoopData = $highlights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $highlight): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php switch($highlight->position):
                case ("large"): ?>
                    <!-- Feed Large -->
                    <article class="feed-large">
                        <div class="feed-info">
                            <a class="feed-type" href="<?php echo e(route('listagem.category', ['category' => $highlight->category->uri])); ?>"><?php echo e($highlight->category->title); ?></a>
                            <a href="<?php echo e(route('noticia', ['uri' => $highlight->uri])); ?>">
                                <h2><?php echo e($highlight->title); ?></h2>
                                <p><?php echo e($highlight->description); ?></p>
                            </a>
                        </div>
                        <a class="feed-cover" href="<?php echo e(route('noticia', ['uri' => $highlight->uri])); ?>">
                            <img src="<?php echo e(url("storage/{$highlight->cover}")); ?>" alt="" />
                        </a>
                        <span class="feed-datetime">
                            <i class="fa-solid fa-clock"></i> <?php echo e(date_fmt_ago($highlight->opening_at)); ?>

                        </span>
                    </article>
                    <?php break; ?>
                <?php case ("medium"): ?>
                    <!-- Feed Medium -->
                    <article class="feed-medium">
                        <div class="feed-info">
                            <a class="feed-type" href="<?php echo e(route('listagem.category', ['category' => $highlight->category->uri])); ?>"><?php echo e($highlight->category->title); ?></a>
                            <a href="<?php echo e(route('noticia', ['uri' => $highlight->uri])); ?>">
                                <h2><?php echo e($highlight->title); ?></h2>
                                <p><?php echo e($highlight->description); ?></p>
                            </a>
                        </div>
                        <a class="feed-cover" href="<?php echo e(route('noticia', ['uri' => $highlight->uri])); ?>">
                            <img src="<?php echo e(url("storage/{$highlight->cover}")); ?>" alt="" />
                        </a>
                        <span class="feed-datetime">
                            <i class="fa-solid fa-clock"></i> <?php echo e(date_fmt_ago($highlight->opening_at)); ?>

                        </span>
                    </article>
                    <?php break; ?>
                <?php case ("small diff"): ?>
                    <!-- Feed Small Diff -->
                    <article class="feed-small diff">
                        <div class="feed-info">
                            <a class="feed-type" href="<?php echo e(route('listagem.category', ['category' => $highlight->category->uri])); ?>"><?php echo e($highlight->category->title); ?></a>
                            <a href="<?php echo e(route('noticia', ['uri' => $highlight->uri])); ?>">
                                <h2><?php echo e($highlight->title); ?></h2>
                                <p><?php echo e($highlight->description); ?></p>
                            </a>
                        </div>
                        <a class="feed-cover" href="<?php echo e(route('noticia', ['uri' => $highlight->uri])); ?>">
                            <img src="<?php echo e(url("storage/{$highlight->cover}")); ?>" alt="" />
                        </a>
                        <div class="feed-author">
                            <div class="feed-author--icon">
                                <img src="<?php echo e(url("storage/{$highlight->user->photo}")); ?>" alt="">
                            </div>
                            <div class="feed-author--info">
                                <h4><?php echo e($highlight->user->fullName()); ?></h4>
                                <span><i class="fa-solid fa-clock"></i> <?php echo e(date_fmt_ago($highlight->opening_at)); ?></span>
                            </div>
                        </div>
                    </article>
                    <?php break; ?>
                <?php case ("small"): ?>
                    <!-- Feed Small -->
                    <article class="feed-small">
                        <div class="feed-info">
                            <a class="feed-type" href="<?php echo e(route('listagem.category', ['category' => $highlight->category->uri])); ?>"><?php echo e($highlight->category->title); ?></a>
                            <a href="<?php echo e(route('noticia', ['uri' => $highlight->uri])); ?>">
                                <h2><?php echo e($highlight->title); ?></h2>
                                <p><?php echo e($highlight->description); ?></p>
                            </a>
                        </div>
                        <a class="feed-cover" href="<?php echo e(route('noticia', ['uri' => $highlight->uri])); ?>">
                            <img src="<?php echo e(url("storage/{$highlight->cover}")); ?>" alt="" />
                        </a>
                        <span class="feed-datetime">
                            <i class="fa-solid fa-clock"></i> <?php echo e(date_fmt_ago($highlight->opening_at)); ?>

                        </span>
                    </article>
                    <?php break; ?>
            <?php endswitch; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <!-- Feed News -->
        <article class="feed-news">
            <div class="header">
                <h4>Últimas notícias</h4>
            </div>
            <div class="body">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="feed" href="<?php echo e(route('noticia', ['uri' => $post->uri])); ?>">
                        <?php if($key == 0): ?> <img src="<?php echo e(url("storage/{$post->cover}")); ?>" alt=""> <?php endif; ?>
                        <span><?php echo e(date_fmt_ago($post->opening_at)); ?></span>
                        <h3><?php echo e($post->title); ?></h3>
                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="footer">
                <a href="<?php echo e(route('listagem', ['type' => 'noticia'])); ?>">VER TODOS</a>
            </div>
        </article>
    </div>
</section><?php /**PATH C:\projetos\newsgames_v2\resources\views/web/common/highlight.blade.php ENDPATH**/ ?>