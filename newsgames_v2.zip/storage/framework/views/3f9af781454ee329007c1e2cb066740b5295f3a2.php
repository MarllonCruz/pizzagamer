<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title><?php echo e(config('app.name')); ?> | Admin</title>
    <link rel="icon" type="image/gif/png" href="<?php echo e(url('storage/article/default.png')); ?>">

    <!-- App Style -->
    <link rel="stylesheet" href="<?php echo e(url(mix('assets/css/adm/login.css'))); ?>">
</head>
<body id="login_body">
    <!-- Ajax Loading -->
    <?php echo $__env->make('adm.common.ajax-load', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main>
        <area class="cover">
        <div class="area-form">
            <form action="<?php echo e(route('admin.login')); ?>" method="post">
                <?php echo csrf_field(); ?>

                <h1>
                    <img src="<?php echo e(url('storage/article/default.png')); ?>" alt="" srcset="">
                    <?php echo e(config('app.name')); ?> Adm
                </h1>
                
                <div class="ajax_response"></div>

                <label for="email">E-mail</label>
                <input type="email" name="email" id="email" placeholder="seu-email@exemplo.com">
    
                <label for="password">Senha</label>
                <input type="password" name="password" id="password" placeholder="********">
            
                <input type="submit" value="Entrar">
            </form>
        </div>
    </main>

    <!-- JQuery -->
    <script src="<?php echo e(url('assets/js/jquery.min.js')); ?>"></script>
    <!-- JQuery Ui -->
    <script src="<?php echo e(url('assets/js/jquery-ui.js')); ?>"></script>
    <!-- App Script -->
    <script src="<?php echo e(url(mix('assets/js/adm/login.js'))); ?>"></script>
</body>
</html><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/login/home.blade.php ENDPATH**/ ?>