<!DOCTYPE html>
<html>
	
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Ghost Gamer <?php echo $__env->yieldContent('title'); ?></title>

	 <!-- Fontawesome style -->
	 <link rel="stylesheet" href="<?php echo e(url(mix('assets/css/fontawesome.css'))); ?>">
	 <!-- App Style -->
	 <link rel="stylesheet" href="<?php echo e(url('assets/css/web/app.css')); ?>">
</head>

<body>
	<!-- Header -->
	<?php echo $__env->make('web.common.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<!-- Content -->
    <?php echo $__env->yieldContent('content'); ?>
	<!-- Footer -->
	<?php echo $__env->make('web.common.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

	<!-- Fontawesome script -->
    <script src="<?php echo e(url('assets/js/fontawesome.js')); ?>"></script>
    <!-- JQuery -->
    <script src="<?php echo e(url('assets/js/jquery.min.js')); ?>"></script>
	<!-- App Script -->
    <script src="<?php echo e(url(mix('assets/js/web/app.js'))); ?>"></script>
    <?php echo $__env->yieldContent('script'); ?>
</body>

</html><?php /**PATH C:\projetos\newsgames_v2\resources\views/web/template.blade.php ENDPATH**/ ?>