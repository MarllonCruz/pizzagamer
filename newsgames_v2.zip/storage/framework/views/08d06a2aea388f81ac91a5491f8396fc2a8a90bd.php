

<?php $__env->startSection('title', " - {$article->title}"); ?>

<?php $__env->startSection('content'); ?>
	 <!-- Article Video -->
     <main class="width-full">
        <article class="article article-video container center">
            <h1><?php echo e($article->title); ?></h1>
            <h3><?php echo e($article->description); ?></h3>
            <div class="video">
                <iframe width="560" class="iframe_1"
                    src="<?php echo e($article->video); ?>"
                    frameborder="0" allow="autoplay; encrypted-media" allowfullscreen></iframe>
            </div>
            <div class="info">
                <div class="author">
                    <div class="avatar"><img src="<?php echo e(url("storage/{$article->user->photo}")); ?>" alt=""></div>
                    <div class="name">Por: <?php echo e($article->user->fullName()); ?></div>
                </div>
                <div class="date"><?php echo e(date_fmt_custom($article->created_at)); ?></div>
            </div>
        </article>
    </main>
    <!-- Others Articles -->
    <?php echo $__env->make('web.common.others-articles', ['routeUri' => 'video'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/web/pages/video.blade.php ENDPATH**/ ?>