

<?php $__env->startSection('content'); ?>
   <section>
      <h2>Artigos/<span>categorias</span></h2>

      <div class="content">
         <div class="left">
            <?php echo $__env->make('adm.posts.common.menu', ['menu', $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
         <div class="right category">
            <header>
               <h2><i class="fa-solid fa-pen-to-square"></i> Categorias</h2>
               <a href="<?php echo e(route('artigos.categorias.create')); ?>"><i class="fa-solid fa-square-plus"></i> Nova categoria</a>
            </header>
            
            <div class="categories">
               <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="category">
                     <div class="cover">
                       <?php if(!empty($category->cover)): ?>
                          <img src="<?php echo e(url('storage/' . $category->cover)); ?>" alt="">      
                       <?php endif; ?>
                     </div>
                     <div class="info">
                        <h2><?php echo e($category->title); ?> <span>[<?php echo e($category->countPosts()); ?> Artigo(s)]</span></h2>
                        <p><?php echo e($category->description); ?></p>
                        <div class="btns">
                           <a href="<?php echo e(route('artigos.categorias.edit', ['category' => $category->id])); ?>"><i class="fa-solid fa-pen"></i> Editar</a>
                           <a href="<?php echo e(route('artigos.categorias.destroy', ['category' => $category->id])); ?>" onclick="return confirm('Tem certeza que deseja excluir categoria <?php echo e($category->title); ?> ?')"><i class="fa-solid fa-trash-can"></i> Deletar</a>
                        </div>
                     </div>
                  </div>
               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            
            <?php echo e($categories->links('adm.common.pagination-custom')); ?>

         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.common.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/posts/categories/home.blade.php ENDPATH**/ ?>