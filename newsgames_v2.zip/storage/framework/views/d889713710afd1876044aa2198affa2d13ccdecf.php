

<?php $__env->startSection('content'); ?>
   <section>
      <h2>Videos</h2>

      <div class="content">
         <div class="left">
            <?php echo $__env->make('adm.videos.common.menu', ['menu', $menu], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
         <div class="right post">
            <header>
               <h2><i class="fa-solid fa-pen-to-square"></i> Videos</h2>

               <form class="form-search" id="form-post-search" action="<?php echo e(route('videos.search.ajax')); ?>" method="post">
                  <?php echo csrf_field(); ?>
                  <button><i class="fa-solid fa-magnifying-glass"></i></button>
                  <input type="text" name="s" value="<?php echo e($search); ?>">
               </form>
            </header>

            <?php echo $__env->make('adm.common.list-post-or-video', [
               'articles' => $articles,
               'route' => 'videos',
               'param' => 'video'
            ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
         </div>
      </div>
   </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adm.common.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/videos/home.blade.php ENDPATH**/ ?>