<ul>
    <li <?php if($menu == 'list'): ?> ?? class="active" <?php endif; ?>>
       <a href="<?php echo e(route('usuarios.index')); ?>"><i class="fa-solid fa-pen-to-square"></i> Lista</a>
    </li>
    <li <?php if($menu == 'new'): ?> ?? class="active" <?php endif; ?>>
       <a href="<?php echo e(route('usuarios.create')); ?>"><i class="fa-solid fa-square-plus"></i> Novo Usuário</a>
    </li>
</ul><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/users/common/menu.blade.php ENDPATH**/ ?>