<ul>
    <li <?php if($menu == 'highlight'): ?> ?? class="active" <?php endif; ?>>
       <a href="<?php echo e(route('destaques.index')); ?>"><i class="fa-solid fa-list-ul"></i> Lista</a>
    </li>
</ul><?php /**PATH C:\projetos\newsgames_v2\resources\views/adm/highlights/common/menu.blade.php ENDPATH**/ ?>