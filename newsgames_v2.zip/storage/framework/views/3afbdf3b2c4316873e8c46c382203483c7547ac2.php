

<?php $__env->startSection('content'); ?>
	<!-- Main Content -->
	<main>
		<!-- Feed SlideShow -->
		<?php echo $__env->make('web.common.slide', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- Feed Highlights -->
		<?php echo $__env->make('web.common.highlight', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<!-- Feed Videos -->
		<?php echo $__env->make('web.common.video', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</main>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('web.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\projetos\newsgames_v2\resources\views/web/pages/index.blade.php ENDPATH**/ ?>